<?php
 
namespace Smallworld\TestApi\Api;
 
interface CustomInterface
{
    /**
     * GET for Post api
     * @param mixed $value
     * @return mixed
     */
 
    public function createCart($value);

    /**
     * save cart.
     * @return
     */

    public function save(\Magento\Quote\Api\Data\CartItemInterface $cartItem);

    /**
     * create cart
     * @api
     * @return mixed
     */
    public function createEmptyCart();

    /**
     * estimateByExtendedAddress
     * @param  $cartId
     * @param \Magento\Quote\Api\Data\AddressInterface $address
     * @return
     */
    public function estimateByExtendedAddress($cartId, \Magento\Quote\Api\Data\AddressInterface $address);

     /**
     * saveAddressInformation
     * @param $cartId
     * @param  \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
     * @return mixed
     */
    public function saveAddressInformation($cartId,
    \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) ;
}