<?php
 
namespace Smallworld\TestApi\Model\Api;
 
use Psr\Log\LoggerInterface;
use \Magento\Quote\Api\Data\CartInterface;
use Smallworld\TestApi\Api\CustomInterface;
use Magento\Quote\Api\ShipmentEstimationInterface;
use \Magento\Quote\Api\Data\AddressInterface;
use Magento\Checkout\Api\Data\ShippingInformationInterface;
use \Magento\Quote\Api\Data\CartItemInterface;
use \Magento\Quote\Api\CartItemRepositoryInterface;
 
class Custom implements CustomInterface
{
     /**
     * @var \Magento\Quote\Api\CartItemRepositoryInterface
     */
    protected $repository;

    protected $logger;
     /**
     * @var \Magento\Quote\Model\ShippingAddressManagementInterface
     */
    private $shippingAddressManagement;

    private $shipmentEstimationManagement;

    /**
     * Constructs a read service object.
     *
     * @param \Magento\Quote\Api\CartItemRepositoryInterface $repository
     */

    public function __construct(
        LoggerInterface $logger,
        \Magento\Quote\Api\CartItemRepositoryInterface $repository
    )
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
         $this->shippingAddressManagement = $objectManager->create(
            \Magento\Quote\Model\ShippingAddressManagementInterface::class
        );
        $this->repository = $repository;
        $this->logger = $logger;
    }
    public function createEmptyCart()
    {
         /** @var $quoteIdMask \Magento\Quote\Model\QuoteIdMask */
         $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
         $quoteManagement = $objectManager->get('\Magento\Quote\Api\CartManagementInterface');
         $quoteIdMaskFactory = $objectManager->get('\Magento\Quote\Model\QuoteIdMaskFactory');
         $quoteIdMask = $quoteIdMaskFactory->create();
         $quoteId = $quoteManagement->createEmptyCart();
         $quoteIdMask->setQuoteId($quoteId)->save();
         return  $quoteIdMask->getMaskedId();
    }

    /**
     * {@inheritdoc}
     */
    public function save(\Magento\Quote\Api\Data\CartItemInterface $cartItem)
    {
        /** @var $quoteIdMask QuoteIdMask */
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
         $quoteIdMaskFactory = $objectManager->get('\Magento\Quote\Model\QuoteIdMaskFactory');
        $quoteIdMask = $quoteIdMaskFactory->create()->load($cartItem->getQuoteId(), 'masked_id');
        $cartItem->setQuoteId($quoteIdMask->getQuoteId());
        $this->repository->save($cartItem);
    }
    public function estimateByExtendedAddress($cartId, \Magento\Quote\Api\Data\AddressInterface $address)
    {
        /** @var $quoteIdMask QuoteIdMask */
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $quoteIdMaskFactory = $objectManager->get('\Magento\Quote\Model\QuoteIdMaskFactory');
        $quoteIdMask = $quoteIdMaskFactory->create()->load($cartId, 'masked_id');
        return $this->getShipmentEstimationManagement()
            ->estimateByExtendedAddress((int) $quoteIdMask->getQuoteId(), $address);
    }
    /**
     * Get shipment estimation management service
     * @return Magento/Quote/Api/ShipmentEstimationInterface
     * @deprecated
     */
    public function getShipmentEstimationManagement()
    {
        if ($this->shipmentEstimationManagement === null) {
            $this->shipmentEstimationManagement =\Magento\Framework\App\ObjectManager::getInstance()
                ->get(ShipmentEstimationInterface::class);
        }
        return $this->shipmentEstimationManagement;
    }
    
   /**
     * {@inheritDoc}
     */
    public function saveAddressInformation($cartId,
    \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    )
    {
        /** @var $quoteIdMask \Magento\Quote\Model\QuoteIdMask */
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $quoteIdMaskFactory = $objectManager->get('\Magento\Quote\Model\QuoteIdMaskFactory');
        $shippingInformationManagement = $objectManager->get('\Magento\Checkout\Api\ShippingInformationManagementInterface');
        $quoteIdMask = $quoteIdMaskFactory->create()->load($cartId, 'masked_id');
        return $shippingInformationManagement->saveAddressInformation(
            $quoteIdMask->getQuoteId(),
            $addressInformation
       );
    }
    /**
     * @inheritdoc
     */
 
    public function createCart($value)
    {
        $data = $value;
        $response = ['success' => false];
 
        try {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
            $store = $storeManager->getStore();
            $websiteId = $storeManager->getStore()->getWebsiteId();
            $quoteId = $this->createEmptyCart();
            $cartRepositoryInterface = $objectManager->get('\Magento\Quote\Api\CartRepositoryInterface');
            $quote = $cartRepositoryInterface->get($quoteId); // load empty cart quote
            $cartItem = $objectManager->get('\Magento\Quote\Api\Data\CartItemInterface');
            $cartItem->setQuoteId($quoteId);
            $i = 0;
            if(Count($data['items']) > 1)
            {
                while($i< Count($data['items']))
                {
                    $cartItem->setQuoteId($quoteId);
                    $cartItem->setSku($data['items'][$i]['sku']);
                    $cartItem->setQty($data['items'][$i]['qty']);
                    $this->save($cartItem);
                    $i++;
                }
            }
            else if(Count($data['items']) == 1){
                $cartItem->setSku($data['items'][0]['sku']);
                $cartItem->setQty($data['items'][0]['qty']);
                $this->save($cartItem);
            }
        
            $addressInterface = $objectManager->get('\Magento\Quote\Api\Data\AddressInterface');
            /** @var \Magento\Quote\Api\Data\AddressInterface $address */
            $shippingAddress = $objectManager->create(\Magento\Quote\Api\Data\AddressInterface::class);

            $addressInterface->setRegion($data['address']['region']);
            $addressInterface->setStreet($data['address']['line2']);
            $addressInterface->setPostcode($data['address']['pincode']) ;
            $addressInterface->setCity($data['address']['city']);
            $addressInterface->setState($data['address']['state']);
            $addressInterface->setCreatedAt($data['created_at']);
            $addressInterface->setOrderStatus($data['order_status']);
            $addressInterface->setComment($data['comments']);
        

            $billingAddress = $objectManager->create(\Magento\Quote\Api\Data\AddressInterface::class);
            $billingAddress->setEmail( $data['billing']['email']);
            $billingAddress->setStreet($data['billing']['address']['line2']);
            $billingAddress->setCity($data['billing']['address']['city']);
            $billingAddress->setTelephone($data['billing']['phone']);
            $billingAddress->setPostcode($data['billing']['address']['pincode']);
            $billingAddress->setRegion($data['billing']['address']['line1']);
            $billingAddress->setFirstName($data['billing']['firstname']);
            $billingAddress->setLastName($data['billing']['lastname']);
            $billingAddress->setCountryId('IN');
            
            $shippingAddress = $objectManager->get('\Magento\Quote\Api\Data\AddressInterface');
            $shippingAddress->setEmail($data['shipping']['email']);
            $shippingAddress->setTelephone($data['shipping']['phone']);
            $shippingAddress->setFirstName($data['shipping']['firstname']);
            $shippingAddress->setLastName($data['shipping']['lastname']);
        // $shippingAddress->setStreet($data['shipping']['address']['line2']);
            // $shippingAddress->setCity($data['shipping']['address']['city']);
            // $shippingAddress->setPostcode($data['shipping']['address']['pincode']);
            // $shippingAddress->setRegion($data['shipping']['address']['region']);
            // $shippingAddress->setState($data['shipping']['address']['lin2']);
            $shippingAddress->setShippingCarrierCode($data['carrier_code']);
            $shippingAddress->setShippingMethodCode($data['method_code']);
            $shippingAddress->setCountryId('IN');
            $shippingAddress->setShippingCarrierCode($data['carrier_code']);
            $shippingAddress->setShippingMethodCode($data['method_code']);
            $addressInfo = $this->estimateByExtendedAddress($quoteId, $addressInterface);
            $shippingManagementInterface = $objectManager->get('\Magento\Checkout\Api\Data\ShippingInformationInterface');
            $shippingManagementInterface->setShippingAddress($shippingAddress);
            $shippingManagementInterface->setBillingAddress($billingAddress);
            $shippingManagementInterface->setShippingCarrierCode($data['carrier_code']);
            $shippingManagementInterface->setShippingMethodCode($data['method_code']);
            // Function to convert array into JSON 
            $this->shippingAddressManagement->assign($quoteId, $shippingAddress);
            $orderAdressInformation = $this->saveAddressInformation($quoteId,$shippingManagementInterface);
        
            $arr = array ( 
                "email"=> $data['email'], 
                "total_price"=> $data['total_price'],
                "total_discount"=>$data['total_discount'],
                "shipping_amount"=>$data['shipping_amount'],
                "cod"=>$data['cod'],
                "cashback"=>$data['cashback'],
                "coupon"=>$data['coupon'],
                "quote_id"=>$quoteId,
                "paymentMethod"=>array(
                    "method" => $data['paymentMethod']['method']),
                "statusHistory"=> array(
                    "comment"=>$data['statusHistory']['comment'],
                    "is_customer_notified"=>$data['statusHistory']['is_customer_notified'],
                    "status"=>$data['statusHistory']['status']
                )
            ); 
            $createOrder = $objectManager->get('Smallworld\Order\Api\OrdercreateInterface');
            $createOrder->createorderfromnewapi($arr);


            $response = ['success' => true, 'message' => 'Order Saved Successfully!!!'];
        } catch (\Exception $e) {
            $response = ['success' => false, 'message' => $e->getMessage()];
            $this->logger->info($e->getMessage());
        }
        $returnArray = json_encode($response);
        return $returnArray; 
    }
}